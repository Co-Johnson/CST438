class Order < ApplicationRecord
end
